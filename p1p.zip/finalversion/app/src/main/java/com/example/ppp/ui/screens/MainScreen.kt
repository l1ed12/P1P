package com.example.ppp.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.ppp.R
import com.example.ppp.Utils
import com.example.ppp.model.Amount
import com.example.ppp.model.Transaction
import com.example.ppp.ui.components.AppButton
import com.example.ppp.ui.theme.income
import com.example.ppp.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import kotlin.math.absoluteValue

@Composable
fun MainScreen(viewModel: MainViewModel, addOrEdit: (Transaction?) -> Unit) {

    val displayState = viewModel.displayState.collectAsState().value
    val transactions = displayState.transactions.collectAsState(listOf())
    val totalIncome = displayState.totalIncome.collectAsState(Amount())
    val totalExpense = displayState.totalExpense.collectAsState(Amount())

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { addOrEdit(null) },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Transparent)
        ) {
            Image(
                painter = painterResource(id = R.drawable.pplyc),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .align(Alignment.Center)
            )
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    for (period in MainViewModel.Period.entries) {
                        AppButton(
                            text = period.getDisplayName(),
                            onClick = { viewModel.setPeriod(period) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TotalItem(isIncome = true, value = totalIncome.value.value)
                    TotalItem(isIncome = false, value = totalExpense.value.value)
                }

                Spacer(modifier = Modifier.height(16.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(transactions.value) { note ->
                        TransactionItem(note, viewModel, addOrEdit)
                    }
                }
            }
        }
    }
}

@Composable
fun TotalItem(
    isIncome: Boolean,
    value: Double
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val bgrey = if (isIncome) income else Color.Red
        Text(
            text = if (isIncome) "Income" else "Expense",
            style = MaterialTheme.typography.bodyMedium,
            color = bgrey
        )
        Text(
            text = Utils.formatAmount(value.absoluteValue),
            style = MaterialTheme.typography.headlineMedium,
            color = bgrey
        )
    }
}

@Composable
fun TransactionItem(
    transaction: Transaction,
    viewModel: MainViewModel,
    edit: (Transaction?) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable { edit(transaction) }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (transaction.amount > 0) "+" else "-",
            color = if (transaction.amount > 0) income else Color.Red,
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = transaction.name,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = Utils.formatAmount(transaction.amount.absoluteValue),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )

            val format = SimpleDateFormat.getDateTimeInstance()
            Text(
                text = format.format(transaction.date),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        IconButton(
            onClick = { viewModel.delete(transaction) }
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = "Delete",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
